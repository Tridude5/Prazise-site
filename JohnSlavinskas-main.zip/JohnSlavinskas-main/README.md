# John Slavinskas — Portfolio

Next.js (app router) + Tailwind portfolio.

### Legal
English **Privacy** and **Imprint** pages are included. No cookies or tracking are used.
